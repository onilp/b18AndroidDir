package com.example.uitest.data.source;

public interface TaskDataSource {
}
